type RateLimitTier = {
  requestsPerMinute: number
  currentRequests: number
  lastReset: number
}

class ApiRateLimiter {
  private limits: Map<string, RateLimitTier> = new Map()

  constructor() {
    // Reset counters every minute
    setInterval(() => this.resetCounters(), 60000)
  }

  private resetCounters() {
    for (const [userId, tier] of this.limits.entries()) {
      if (Date.now() - tier.lastReset >= 60000) {
        this.limits.set(userId, {
          ...tier,
          currentRequests: 0,
          lastReset: Date.now(),
        })
      }
    }
  }

  setUserTier(userId: string, requestsPerMinute: number) {
    this.limits.set(userId, {
      requestsPerMinute,
      currentRequests: 0,
      lastReset: Date.now(),
    })
  }

  canMakeRequest(userId: string): boolean {
    const tier = this.limits.get(userId)
    if (!tier) return false

    if (tier.currentRequests >= tier.requestsPerMinute) {
      return false
    }

    tier.currentRequests++
    return true
  }

  getRemainingRequests(userId: string): number {
    const tier = this.limits.get(userId)
    if (!tier) return 0
    return Math.max(0, tier.requestsPerMinute - tier.currentRequests)
  }
}

export const apiLimiter = new ApiRateLimiter()

