const API_KEY = process.env.ALPHA_VANTAGE_API_KEY;

export async function getStockData(symbol: string, days: number) {
  try {
    const response = await fetch(`https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&apikey=${API_KEY}`);
    const data = await response.json();

    if (data['Note']) {
      // API rate limit reached
      throw new Error('API rate limit reached. Please try again in a minute.');
    }

    if (data['Error Message']) {
      throw new Error('Invalid stock symbol. Please check and try again.');
    }

    const timeSeries = data['Time Series (Daily)'];
    if (!timeSeries) {
      throw new Error('No data available for this stock symbol.');
    }

    const dates = Object.keys(timeSeries).slice(0, days).reverse();
    const stockData = dates.map(date => ({
      date,
      price: parseFloat(timeSeries[date]['4. close']),
      change: parseFloat(timeSeries[date]['4. close']) - parseFloat(timeSeries[date]['1. open'])
    }));

    const currentPrice = stockData[stockData.length - 1].price;
    
    // Enhanced prediction using exponential moving average
    const weights = stockData.map((_, index) => Math.exp(index / stockData.length));
    const weightSum = weights.reduce((a, b) => a + b, 0);
    const avgChange = stockData.reduce((sum, day, index) => sum + day.change * weights[index], 0) / weightSum;
    const prediction = currentPrice + (avgChange * 5); // Predict 5 days ahead

    return {
      symbol,
      currentPrice: currentPrice.toFixed(2),
      prediction: prediction.toFixed(2),
      data: stockData,
    };
  } catch (error) {
    throw error;
  }
}

