import { initializeApp, getApps } from "firebase/app"
import { getAuth, GoogleAuthProvider } from "firebase/auth"

const firebaseConfig = {
  apiKey: "AIzaSyCOaYrqoPEz0ABvAOA1ihMU0caDPapMUk4",
  authDomain: "ai12-60860.firebaseapp.com",
  projectId: "ai12-60860",
  storageBucket: "ai12-60860.firebasestorage.app",
  messagingSenderId: "277533098617",
  appId: "1:277533098617:web:b92ec909bbc75686cd8aa8",
  measurementId: "G-VX5M455H2V",
}

// Initialize Firebase
let app
if (typeof window !== "undefined" && !getApps().length) {
  app = initializeApp(firebaseConfig)
}

export const auth = getAuth(app)
export const googleProvider = new GoogleAuthProvider()

