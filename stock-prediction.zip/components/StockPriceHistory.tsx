"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { ErrorMessage } from "@/components/ui/error-message"
import { EmptyState } from "@/components/ui/empty-state"

interface StockPriceHistoryProps {
  symbol: string
}

interface StockData {
  date: string
  price: number
}

export function StockPriceHistory({ symbol }: StockPriceHistoryProps) {
  const [data, setData] = useState<StockData[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchHistoricalData = async () => {
      if (!symbol) return

      setLoading(true)
      setError(null)
      try {
        const response = await fetch(`/api/stock-history?symbol=${symbol}`)
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const result = await response.json()
        if (result.error) {
          throw new Error(result.error)
        }
        if (!Array.isArray(result) || result.length === 0) {
          throw new Error("No historical data available")
        }
        setData(result)
      } catch (err) {
        console.error("Error fetching historical data:", err)
        setError(err instanceof Error ? err.message : "Failed to fetch historical data")
        setData([])
      } finally {
        setLoading(false)
      }
    }

    fetchHistoricalData()
  }, [symbol])

  const formatDate = (date: string) => {
    const d = new Date(date)
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
  }

  const formatCurrency = (value: number) => `$${value.toFixed(2)}`

  if (loading) return <LoadingSpinner />
  if (error) return <ErrorMessage message={error} />
  if (data.length === 0) return <EmptyState message="No historical data available." />

  return (
    <Card className="bg-black text-white">
      <CardHeader>
        <CardTitle>45-Year Stock Price History: {symbol}</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart
            data={data}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#444" />
            <XAxis dataKey="date" stroke="#fff" tickFormatter={formatDate} tick={{ fill: "#fff" }} />
            <YAxis stroke="#fff" tickFormatter={formatCurrency} tick={{ fill: "#fff" }} />
            <Tooltip
              contentStyle={{ backgroundColor: "#333", border: "none" }}
              labelFormatter={formatDate}
              formatter={(value: number) => [formatCurrency(value), "Price"]}
            />
            <Line type="monotone" dataKey="price" stroke="#8884d8" dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

