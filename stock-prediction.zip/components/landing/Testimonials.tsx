import { Card, CardContent } from "@/components/ui/card"
import { useEffect, useRef, useState } from "react"
import Image from "next/image"

const testimonials = [
  {
    quote: "StockPredictor has transformed my investment strategy. The AI-powered insights are invaluable!",
    author: "Jane Doe",
    title: "Individual Investor",
    gradient: "from-purple-400 to-pink-600",
  },
  {
    quote: "The real-time data and advanced analytics have given us a significant edge in the market.",
    author: "John Smith",
    title: "Portfolio Manager, TechInvest",
    gradient: "from-green-400 to-blue-500",
  },
  {
    quote: "StockPredictor's user-friendly interface makes complex market data accessible to everyone.",
    author: "Alice Johnson",
    title: "Financial Advisor",
    gradient: "from-yellow-400 to-red-500",
  },
  {
    quote: "We've seen a 40% improvement in our trading performance since implementing StockPredictor.",
    author: "Bob Williams",
    title: "Head Trader, QuickTrade Inc.",
    gradient: "from-indigo-400 to-cyan-400",
  },
]

export function Testimonials() {
  const [isHovered, setIsHovered] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const scrollContainer = scrollRef.current
    if (!scrollContainer) return

    const scrollContent = scrollContainer.firstElementChild as HTMLElement
    if (!scrollContent) return

    const scrollWidth = scrollContent.offsetWidth
    let scrollPosition = 0

    const scroll = () => {
      if (isHovered) return
      scrollPosition += 0.5
      if (scrollPosition >= scrollWidth / 2) {
        scrollPosition = 0
      }
      scrollContainer.scrollLeft = scrollPosition
    }

    const intervalId = setInterval(scroll, 20)

    return () => clearInterval(intervalId)
  }, [isHovered])

  return (
    <section id="testimonials" className="bg-gray-100 py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">What Our Customers Say</h2>
        <div
          className="overflow-hidden"
          ref={scrollRef}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div className="flex">
            {[...testimonials, ...testimonials].map((testimonial, index) => (
              <Card key={index} className="flex-shrink-0 w-[300px] mx-4">
                <CardContent className="p-6">
                  <p className="text-lg mb-4">"{testimonial.quote}"</p>
                  <div className="flex items-center">
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${testimonial.gradient} mr-4`}></div>
                    <div>
                      <p className="font-semibold">{testimonial.author}</p>
                      <p className="text-sm text-gray-600">{testimonial.title}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

