import { Button } from "@/components/ui/button"
import Link from "next/link"

export function Hero() {
  return (
    <section className="bg-gray-100 py-20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-5xl font-bold mb-4">Predict Stock Trends with Confidence</h1>
        <p className="text-xl mb-8">Make informed investment decisions with our advanced stock prediction tools</p>
        <Link href="/signup">
          <Button size="lg">Start Your Free Trial</Button>
        </Link>
      </div>
    </section>
  )
}

