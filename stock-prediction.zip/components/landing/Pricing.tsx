import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import Link from "next/link"

const pricingPlans = [
  {
    name: "Basic",
    price: "$9.99",
    description: "Perfect for beginners",
    features: ["5 stock predictions/day", "Basic analytics", "24/7 support"],
    recommended: false,
  },
  {
    name: "Pro",
    price: "$19.99",
    description: "Ideal for active traders",
    features: ["Unlimited predictions", "Advanced analytics", "Priority support", "Portfolio management"],
    recommended: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "For professional investors",
    features: ["Custom solutions", "Dedicated account manager", "API access", "Advanced AI models"],
    recommended: false,
  },
]

export function Pricing() {
  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Choose Your Plan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingPlans.map((plan, index) => (
            <Card
              key={index}
              className={`flex flex-col h-full transition-all duration-300 ${
                plan.recommended
                  ? "border-primary shadow-lg scale-105"
                  : "hover:border-primary hover:shadow-md hover:scale-105"
              }`}
            >
              <CardHeader>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-4xl font-bold mb-4">
                  {plan.price}
                  <span className="text-sm font-normal">/month</span>
                </p>
                <ul className="space-y-2">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="h-5 w-5 text-green-500 mr-2" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/signup" className="w-full">
                  <Button className={`w-full ${plan.recommended ? "bg-primary hover:bg-primary/90" : ""}`}>
                    {plan.recommended ? "Get Started" : "Choose Plan"}
                  </Button>
                </Link>
              </CardFooter>
              {plan.recommended && (
                <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-lg">
                  Recommended
                </div>
              )}
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

