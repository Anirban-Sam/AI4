import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { auth } from "@/lib/firebase"
import type { User } from "firebase/auth"
import { TrendingUp } from "lucide-react"

export function Layout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setUser(user)
    })

    return () => unsubscribe()
  }, [])

  const handleSignOut = async () => {
    try {
      await auth.signOut()
      router.push("/landing")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <header className="bg-white shadow-md py-4 fixed top-0 left-0 right-0 z-50">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <Link href="/" className="flex items-center">
            <TrendingUp className="h-8 w-8 text-primary mr-2" />
            <span className="text-2xl font-bold">StockPredictor</span>
          </Link>
          {user ? (
            <div className="flex items-center space-x-4">
              {user && (
                <Link href="/dashboard">
                  <Button variant="ghost">Go to Dashboard</Button>
                </Link>
              )}
            </div>
          ) : (
            <Link href="/signup">
              <Button>Sign In</Button>
            </Link>
          )}
        </div>
      </header>
      <main className="flex-grow mt-16">{children}</main>
    </div>
  )
}

