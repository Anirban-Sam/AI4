import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface HistoricalPerformanceProps {
  data: Array<{ date: string; price: number }>
}

export function HistoricalPerformance({ data }: HistoricalPerformanceProps) {
  const calculateReturns = () => {
    if (data.length < 2) return { daily: 0, weekly: 0, monthly: 0, yearly: 0 }

    const latestPrice = data[data.length - 1].price
    const oneDayAgo = data[data.length - 2].price
    const oneWeekAgo = data[Math.max(0, data.length - 8)].price
    const oneMonthAgo = data[Math.max(0, data.length - 31)].price
    const oneYearAgo = data[0].price

    return {
      daily: ((latestPrice - oneDayAgo) / oneDayAgo) * 100,
      weekly: ((latestPrice - oneWeekAgo) / oneWeekAgo) * 100,
      monthly: ((latestPrice - oneMonthAgo) / oneMonthAgo) * 100,
      yearly: ((latestPrice - oneYearAgo) / oneYearAgo) * 100,
    }
  }

  const returns = calculateReturns()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Historical Performance</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Time Frame</TableHead>
              <TableHead>Return</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell>Daily</TableCell>
              <TableCell>{returns.daily.toFixed(2)}%</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Weekly</TableCell>
              <TableCell>{returns.weekly.toFixed(2)}%</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Monthly</TableCell>
              <TableCell>{returns.monthly.toFixed(2)}%</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Yearly</TableCell>
              <TableCell>{returns.yearly.toFixed(2)}%</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

