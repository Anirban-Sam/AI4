"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Info } from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { StockPriceHistory } from "./StockPriceHistory"
import { HistoricalPerformance } from "./HistoricalPerformance"
import { NewsSentiment } from "./NewsSentiment"
import { StockComparison } from "./StockComparison"
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export function MarketData() {
  const [symbol, setSymbol] = useState("")
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [prediction, setPrediction] = useState<{
    currentPrice: number
    predictedPrice: number
    potentialChange: number
    percentageChange: number
  } | null>(null)

  const fetchData = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch(`/api/stock-info?symbol=${symbol}`)
      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.details || `HTTP error! status: ${response.status}`)
      }

      if (result.error) {
        throw new Error(result.details || result.error)
      }

      setData(result)
      calculatePrediction(result)
    } catch (err) {
      console.error("Error fetching stock data:", err)
      setError(err instanceof Error ? err.message : "Failed to fetch stock data")
      setData(null)
      setPrediction(null)
    } finally {
      setLoading(false)
    }
  }

  const calculatePrediction = (data: any) => {
    if (!data || !data.historicalData || data.historicalData.length === 0) {
      console.error("Invalid data for prediction calculation")
      return
    }

    const prices = data.historicalData.map((item: any) => item.price)
    const n = prices.length
    let sumX = 0,
      sumY = 0,
      sumXY = 0,
      sumX2 = 0
    for (let i = 0; i < n; i++) {
      sumX += i
      sumY += prices[i]
      sumXY += i * prices[i]
      sumX2 += i * i
    }

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX)
    const intercept = (sumY - slope * sumX) / n

    const currentPrice = prices[prices.length - 1]
    const predictedPrice = slope * (n + 7) + intercept // 7 days prediction
    const potentialChange = predictedPrice - currentPrice
    const percentageChange = (potentialChange / currentPrice) * 100

    setPrediction({
      currentPrice,
      predictedPrice,
      potentialChange,
      percentageChange,
    })
  }

  const formatChartData = (data: any) => {
    if (!data || !data.historicalData) return []

    return data.historicalData.map((item: any) => ({
      date: new Date(item.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      price: item.price,
    }))
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Advanced Stock Predictor</CardTitle>
        <CardDescription>Enter a stock symbol to predict its future price and analyze performance.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex gap-4 mb-6">
          <Input
            placeholder="Enter stock symbol (e.g., AAPL)"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            className="flex-grow"
          />
          <Button onClick={fetchData} disabled={loading || !symbol}>
            Predict & Analyze
          </Button>
        </div>

        {loading && <div className="text-center py-4">Loading...</div>}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {data && prediction && (
          <>
            <div className="flex gap-4 mb-6">
              <Card className="flex-1 bg-blue-50">
                <CardContent className="pt-6">
                  <div className="text-sm text-blue-600 mb-1">Current Price</div>
                  <div className="text-2xl font-bold text-blue-700">${prediction.currentPrice.toFixed(2)}</div>
                  <div className="text-xs text-blue-500">{symbol}</div>
                </CardContent>
              </Card>

              <Card className="flex-1 bg-purple-50">
                <CardContent className="pt-6">
                  <div className="text-sm text-purple-600 mb-1">Predicted Price (7 Days)</div>
                  <div className="text-2xl font-bold text-purple-700">${prediction.predictedPrice.toFixed(2)}</div>
                  <div className="text-xs text-purple-500">Forecast</div>
                </CardContent>
              </Card>

              <Card className="flex-1 bg-green-50">
                <CardContent className="pt-6">
                  <div className="text-sm text-green-600 mb-1">
                    Potential {prediction.potentialChange < 0 ? "Loss" : "Gain"}
                  </div>
                  <div className="text-2xl font-bold text-green-700">
                    ${Math.abs(prediction.potentialChange).toFixed(2)}
                  </div>
                  <div className="text-xs text-green-500">{prediction.percentageChange.toFixed(2)}%</div>
                </CardContent>
              </Card>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <div className="flex items-center gap-2 mb-4">
                <Info className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">Using daily data for predictions and analysis.</span>
              </div>

              <Tabs defaultValue="price-chart">
                <TabsList>
                  <TabsTrigger value="price-chart">Price Chart</TabsTrigger>
                  <TabsTrigger value="historical">Historical Performance</TabsTrigger>
                  <TabsTrigger value="news">News Sentiment</TabsTrigger>
                  <TabsTrigger value="comparison">Comparison</TabsTrigger>
                  <TabsTrigger value="history">45-Year History</TabsTrigger>
                </TabsList>

                <TabsContent value="price-chart" className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={formatChartData(data)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" tick={{ fontSize: 12 }} angle={-45} textAnchor="end" height={60} />
                      <YAxis domain={["auto", "auto"]} tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Line type="monotone" dataKey="price" stroke="#8884d8" name="Price" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </TabsContent>

                <TabsContent value="historical">
                  <HistoricalPerformance data={data?.historicalData} />
                </TabsContent>

                <TabsContent value="news">
                  <NewsSentiment symbol={symbol} />
                </TabsContent>

                <TabsContent value="comparison">
                  <StockComparison symbol1={symbol} symbol2="SPY" />
                </TabsContent>

                <TabsContent value="history">
                  <StockPriceHistory symbol={symbol} />
                </TabsContent>
              </Tabs>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}

