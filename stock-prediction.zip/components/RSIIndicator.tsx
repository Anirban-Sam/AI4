import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'

interface RSIData {
  date: string
  RSI: string
}

interface RSIIndicatorProps {
  data: Record<string, { RSI: string }>
  timePeriod: number
}

export function RSIIndicator({ data, timePeriod }: RSIIndicatorProps) {
  const chartData: RSIData[] = Object.entries(data)
    .map(([date, values]) => ({ date, ...values }))
    .slice(0, 30) // Show last 30 data points
    .reverse()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Relative Strength Index (RSI)</CardTitle>
        <CardDescription>Time Period: {timePeriod} days</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <ReferenceLine y={30} stroke="green" strokeDasharray="3 3" />
            <ReferenceLine y={70} stroke="red" strokeDasharray="3 3" />
            <Line type="monotone" dataKey="RSI" stroke="black" strokeWidth={2} dot={false} /> {/*Removed hsl and used black instead*/}
          </LineChart>
        </ResponsiveContainer>
        <div className="mt-4">
          <p className="font-semibold">Latest RSI: {chartData[chartData.length - 1]?.RSI}</p>
          <p className="text-sm text-muted-foreground">
            As of {chartData[chartData.length - 1]?.date}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

