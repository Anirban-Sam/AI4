import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'

interface SMAData {
  date: string
  SMA: string
}

interface SMAIndicatorProps {
  data: Record<string, { SMA: string }>
  timePeriod: number
}

export function SMAIndicator({ data, timePeriod }: SMAIndicatorProps) {
  const chartData: SMAData[] = Object.entries(data)
    .map(([date, values]) => ({ date, ...values }))
    .slice(0, 30) // Show last 30 data points
    .reverse()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Simple Moving Average (SMA)</CardTitle>
        <CardDescription>Time Period: {timePeriod} days</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="SMA" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
        <div className="mt-4">
          <p className="font-semibold">Latest SMA: {chartData[chartData.length - 1]?.SMA}</p>
          <p className="text-sm text-muted-foreground">
            As of {chartData[chartData.length - 1]?.date}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

interface RSIData {
  date: string
  RSI: string
}

interface RSIIndicatorProps {
  data: Record<string, { RSI: string }>
  timePeriod: number
}

export function RSIIndicator({ data, timePeriod }: RSIIndicatorProps) {
  const chartData: RSIData[] = Object.entries(data)
    .map(([date, values]) => ({ date, ...values }))
    .slice(0, 30) // Show last 30 data points
    .reverse()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Relative Strength Index (RSI)</CardTitle>
        <CardDescription>Time Period: {timePeriod} days</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <ReferenceLine y={30} stroke="green" strokeDasharray="3 3" />
            <ReferenceLine y={70} stroke="red" strokeDasharray="3 3" />
            <Line type="monotone" dataKey="RSI" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
        <div className="mt-4">
          <p className="font-semibold">Latest RSI: {chartData[chartData.length - 1]?.RSI}</p>
          <p className="text-sm text-muted-foreground">
            As of {chartData[chartData.length - 1]?.date}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

interface MACDData {
  date: string
  MACD: string
  MACD_Hist: string
  MACD_Signal: string
}

interface MACDIndicatorProps {
  data: Record<string, { MACD: string, MACD_Hist: string, MACD_Signal: string }>
}

export function MACDIndicator({ data }: MACDIndicatorProps) {
  const chartData: MACDData[] = Object.entries(data)
    .map(([date, values]) => ({ date, ...values }))
    .slice(0, 30) // Show last 30 data points
    .reverse()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Moving Average Convergence Divergence (MACD)</CardTitle>
        <CardDescription>12-26 day EMA difference, 9 day EMA of MACD</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="MACD_Hist" fill="hsl(var(--primary))" />
            <Line type="monotone" dataKey="MACD" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="MACD_Signal" stroke="hsl(var(--secondary))" strokeWidth={2} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
        <div className="mt-4 grid grid-cols-3 gap-4">
          <div>
            <p className="font-semibold">MACD</p>
            <p>{chartData[chartData.length - 1]?.MACD}</p>
          </div>
          <div>
            <p className="font-semibold">Signal</p>
            <p>{chartData[chartData.length - 1]?.MACD_Signal}</p>
          </div>
          <div>
            <p className="font-semibold">Histogram</p>
            <p>{chartData[chartData.length - 1]?.MACD_Hist}</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          As of {chartData[chartData.length - 1]?.date}
        </p>
      </CardContent>
    </Card>
  )
}

