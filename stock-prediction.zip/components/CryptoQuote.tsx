import { motion } from "framer-motion"
import { TrendingUp, TrendingDown, Volume2 } from 'lucide-react'
import { Card, CardContent } from "@/components/ui/card"

interface CryptoQuoteProps {
  data: {
    symbol: string
    price: number
    volume: number
    marketCap?: number
    change24h: number
    high24h: number
    low24h: number
    timestamp: string
  }
}

export function CryptoQuote({ data }: CryptoQuoteProps) {
  const isPositiveChange = data.change24h >= 0
  const changePercent = ((data.change24h / (data.price - data.change24h)) * 100).toFixed(2)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-4"
    >
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold">{data.symbol}/USD</h2>
          <p className="text-sm text-muted-foreground">
            Last updated: {new Date(data.timestamp).toLocaleString()}
          </p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold">${data.price.toLocaleString()}</div>
          <div className={`flex items-center justify-end ${isPositiveChange ? 'text-green-500' : 'text-red-500'}`}>
            {isPositiveChange ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
            <span className="font-medium">${Math.abs(data.change24h).toLocaleString()} ({changePercent}%)</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground mb-2">24h Range</div>
            <div className="font-medium">
              ${data.low24h.toLocaleString()} - ${data.high24h.toLocaleString()}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground mb-2">
              <div className="flex items-center">
                <Volume2 className="w-4 h-4 mr-1" />
                24h Volume
              </div>
            </div>
            <div className="font-medium">${data.volume.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-muted-foreground mb-2">Market Cap</div>
            <div className="font-medium">
              ${data.marketCap ? data.marketCap.toLocaleString() : 'N/A'}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="relative pt-2">
        <div className="w-full bg-muted rounded-full h-2">
          <div
            className="bg-primary h-2 rounded-full"
            style={{
              width: `${((data.price - data.low24h) / (data.high24h - data.low24h)) * 100}%`
            }}
          />
        </div>
        <div className="flex justify-between text-sm text-muted-foreground mt-2">
          <span>24h Low: ${data.low24h.toLocaleString()}</span>
          <span>24h High: ${data.high24h.toLocaleString()}</span>
        </div>
      </div>
    </motion.div>
  )
}

