import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { ErrorMessage } from "@/components/ui/error-message"
import { EmptyState } from "@/components/ui/empty-state"

interface StockComparisonProps {
  symbol1: string
  symbol2: string
}

export function StockComparison({ symbol1, symbol2 }: StockComparisonProps) {
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [comparisonResult, setComparisonResult] = useState<string | null>(null)

  useEffect(() => {
    const fetchComparisonData = async () => {
      if (!symbol1 || !symbol2) return

      setLoading(true)
      setError(null)
      try {
        const response = await fetch(`/api/stock-comparison?symbol1=${symbol1}&symbol2=${symbol2}`)
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const result = await response.json()
        if (result.error) {
          throw new Error(result.error)
        }
        if (!result.data || !Array.isArray(result.data) || result.data.length === 0) {
          throw new Error("No comparison data available")
        }
        setData(result.data)
        setComparisonResult(result.comparisonResult)
      } catch (err) {
        console.error("Error fetching comparison data:", err)
        setError(err instanceof Error ? err.message : "Failed to fetch comparison data")
        setData([])
      } finally {
        setLoading(false)
      }
    }

    fetchComparisonData()
  }, [symbol1, symbol2])

  if (loading) return <LoadingSpinner />
  if (error) return <ErrorMessage message={error} />
  if (data.length === 0) return <EmptyState message="No comparison data available." />

  return (
    <Card className="bg-black text-white">
      <CardHeader>
        <CardTitle>
          Stock Comparison: {symbol1} vs {symbol2}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#444" />
            <XAxis dataKey="date" stroke="#fff" />
            <YAxis stroke="#fff" />
            <Tooltip contentStyle={{ backgroundColor: "#333", border: "none" }} />
            <Legend />
            <Line type="monotone" dataKey={symbol1} stroke="#8884d8" />
            <Line type="monotone" dataKey={symbol2} stroke="#82ca9d" />
          </LineChart>
        </ResponsiveContainer>
        {comparisonResult && (
          <div className="mt-4 p-4 bg-gray-800 rounded-md">
            <h3 className="text-lg font-semibold mb-2">Comparison Result:</h3>
            <p>{comparisonResult}</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

