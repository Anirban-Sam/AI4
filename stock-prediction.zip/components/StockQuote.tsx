import { motion } from "framer-motion"
import { ArrowUpIcon, ArrowDownIcon } from "lucide-react"

interface StockQuoteProps {
  data: {
    symbol: string
    open: string
    high: string
    low: string
    price: string
    volume: string
    latestTradingDay: string
    previousClose: string
    change: string
    changePercent: string
  }
}

export function StockQuote({ data }: StockQuoteProps) {
  const isPositiveChange = Number.parseFloat(data.change) >= 0

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-card text-card-foreground rounded-lg shadow-lg p-6 max-w-2xl mx-auto"
    >
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-3xl font-bold">{data.symbol}</h2>
        <div className="text-right">
          <p className="text-2xl font-semibold">${data.price}</p>
          <div className={`flex items-center ${isPositiveChange ? "text-green-500" : "text-red-500"}`}>
            {isPositiveChange ? <ArrowUpIcon className="w-4 h-4 mr-1" /> : <ArrowDownIcon className="w-4 h-4 mr-1" />}
            <span className="font-medium">
              {data.change} ({data.changePercent})
            </span>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-muted-foreground">Open</p>
          <p className="font-medium">${data.open}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Previous Close</p>
          <p className="font-medium">${data.previousClose}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Day's Range</p>
          <p className="font-medium">
            ${data.low} - ${data.high}
          </p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Volume</p>
          <p className="font-medium">{Number.parseInt(data.volume).toLocaleString()}</p>
        </div>
      </div>
      <div className="mt-4 text-sm text-muted-foreground text-right">
        As of {new Date(data.latestTradingDay).toLocaleDateString()}
      </div>
    </motion.div>
  )
}

