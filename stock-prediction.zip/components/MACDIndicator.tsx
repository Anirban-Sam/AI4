import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Bar, ComposedChart } from 'recharts'

interface MACDData {
  date: string
  MACD: number
  MACD_Hist: number
  MACD_Signal: number
}

interface MACDIndicatorProps {
  data: Record<string, { MACD: number, MACD_Hist: number, MACD_Signal: number }>
}

export function MACDIndicator({ data }: MACDIndicatorProps) {
  const chartData: MACDData[] = Object.entries(data)
    .map(([date, values]) => ({ date, ...values }))
    .slice(0, 30) // Show last 30 data points
    .reverse()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Moving Average Convergence Divergence (MACD)</CardTitle>
        <CardDescription>12-26 day EMA difference, 9 day EMA of MACD</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="MACD_Hist" fill="hsl(var(--primary))" />
            <Line type="monotone" dataKey="MACD" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="MACD_Signal" stroke="hsl(var(--secondary))" strokeWidth={2} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
        <div className="mt-4 grid grid-cols-3 gap-4">
          <div>
            <p className="font-semibold">MACD</p>
            <p>{chartData[chartData.length - 1]?.MACD}</p>
          </div>
          <div>
            <p className="font-semibold">Signal</p>
            <p>{chartData[chartData.length - 1]?.MACD_Signal}</p>
          </div>
          <div>
            <p className="font-semibold">Histogram</p>
            <p>{chartData[chartData.length - 1]?.MACD_Hist}</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          As of {chartData[chartData.length - 1]?.date}
        </p>
      </CardContent>
    </Card>
  )
}

