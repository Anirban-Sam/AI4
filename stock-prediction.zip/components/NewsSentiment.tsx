"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { ErrorMessage } from "@/components/ui/error-message"
import { EmptyState } from "@/components/ui/empty-state"

interface NewsSentimentProps {
  symbol: string
}

export function NewsSentiment({ symbol }: NewsSentimentProps) {
  const [news, setNews] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchNews = async () => {
      if (!symbol) return
      setLoading(true)
      setError(null)
      try {
        const response = await fetch(`/api/news-sentiment?symbol=${symbol}`)
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const data = await response.json()
        if (data.error) {
          throw new Error(data.error)
        }
        if (!Array.isArray(data) || data.length === 0) {
          throw new Error("No news data available")
        }
        setNews(data.slice(0, 5)) // Display top 5 news items
      } catch (err) {
        console.error("Error fetching news:", err)
        setError(err instanceof Error ? err.message : "Failed to fetch news data")
      } finally {
        setLoading(false)
      }
    }

    fetchNews()
  }, [symbol])

  if (loading) return <LoadingSpinner />
  if (error) return <ErrorMessage message={error} />
  if (news.length === 0) return <EmptyState message="No news available for this stock." />

  return (
    <Card className="bg-black text-white">
      <CardHeader>
        <CardTitle>Latest News and Sentiment</CardTitle>
      </CardHeader>
      <CardContent>
        {news.map((item, index) => (
          <div key={index} className="mb-4 border-b border-gray-700 pb-4 last:border-b-0 last:pb-0">
            <h3 className="font-semibold text-lg">{item.title}</h3>
            <p className="text-sm text-gray-300 mt-1">{item.summary}</p>
            <p className="text-xs text-gray-400 mt-2">
              Sentiment: {item.sentiment} | Source: {item.source} | Published:{" "}
              {new Date(item.publishedAt).toLocaleString()}
            </p>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

