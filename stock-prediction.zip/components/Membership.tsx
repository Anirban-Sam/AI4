import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

export function Membership() {
  return (
    <div className="py-8" id="membership">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">Membership Plans</CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <InfoIcon className="h-4 w-4" />
            <AlertDescription>
              We're currently updating our membership plans. Please check back later for new offerings.
            </AlertDescription>
          </Alert>
          <p className="mt-4 text-center text-gray-600">
            In the meantime, you can continue to use our basic features free of charge.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

