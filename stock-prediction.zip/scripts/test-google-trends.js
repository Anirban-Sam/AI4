const googleTrends = require("google-trends-api")

async function testGoogleTrends() {
  try {
    console.log("Fetching Google Trends...")
    const result = await googleTrends.dailyTrends({
      geo: "US",
    })
    const trends = JSON.parse(result).default.trendingSearchesDays[0].trendingSearches
    console.log(`Successfully fetched ${trends.length} trends`)
    console.log("First trend:", trends[0].title)
  } catch (error) {
    console.error("Error fetching Google Trends:", error)
  }
}

testGoogleTrends()

