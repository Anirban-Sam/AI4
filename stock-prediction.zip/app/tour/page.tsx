"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface TourStep {
  title: string
  description: string
  position: { top: string; left: string }
  highlight: { top: string; left: string; width: string; height: string }
}

const tourSteps: TourStep[] = [
  {
    title: "Welcome to Stock Predictor",
    description: "Let's take a quick tour of our main features. Click 'Next' to continue.",
    position: { top: "50%", left: "50%" },
    highlight: { top: "0", left: "0", width: "0", height: "0" },
  },
  {
    title: "Stock Search",
    description: "Enter any stock symbol here to get real-time predictions and analysis.",
    position: { top: "20%", left: "50%" },
    highlight: { top: "15%", left: "20%", width: "300px", height: "50px" },
  },
  {
    title: "Price Charts",
    description: "View detailed price charts with technical indicators and predictions.",
    position: { top: "40%", left: "60%" },
    highlight: { top: "30%", left: "20%", width: "60%", height: "300px" },
  },
  {
    title: "Market Analysis",
    description: "Access comprehensive market analysis and news for informed decisions.",
    position: { top: "60%", left: "40%" },
    highlight: { top: "50%", left: "20%", width: "60%", height: "200px" },
  },
]

export default function TourPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)

  const handleNext = () => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep((prev) => prev + 1)
    } else {
      router.push("/membership")
    }
  }

  const handleSkip = () => {
    router.push("/membership")
  }

  const currentTourStep = tourSteps[currentStep]

  return (
    <div className="fixed inset-0 bg-black/50 z-50">
      <div
        className="absolute bg-primary/20 pointer-events-none transition-all duration-300"
        style={{
          top: currentTourStep.highlight.top,
          left: currentTourStep.highlight.left,
          width: currentTourStep.highlight.width,
          height: currentTourStep.highlight.height,
          border: "2px solid hsl(var(--primary))",
          borderRadius: "8px",
        }}
      />

      <Card
        className="absolute max-w-md transition-all duration-300"
        style={{
          top: currentTourStep.position.top,
          left: currentTourStep.position.left,
          transform: "translate(-50%, -50%)",
        }}
      >
        <CardContent className="p-6">
          <h3 className="text-xl font-bold mb-2">{currentTourStep.title}</h3>
          <p className="text-gray-600 mb-6">{currentTourStep.description}</p>
          <div className="flex justify-between items-center">
            <Button variant="outline" onClick={handleSkip}>
              Skip Tour
            </Button>
            <div className="flex items-center gap-2">
              <div className="text-sm text-gray-500">
                {currentStep + 1} of {tourSteps.length}
              </div>
              <Button onClick={handleNext}>{currentStep === tourSteps.length - 1 ? "Finish" : "Next"}</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

