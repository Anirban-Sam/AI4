import { NextResponse } from "next/server"

const API_KEY = process.env.ALPHA_VANTAGE_API_KEY

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const symbol = searchParams.get("symbol")

  if (!symbol) {
    return NextResponse.json({ error: "Symbol is required" }, { status: 400 })
  }

  if (!API_KEY) {
    return NextResponse.json({ error: "API key is not configured" }, { status: 500 })
  }

  try {
    const response = await fetch(
      `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&apikey=${API_KEY}`,
    )

    if (!response.ok) {
      throw new Error(`API responded with status ${response.status}`)
    }

    const data = await response.json()

    if (data["Error Message"]) {
      throw new Error(data["Error Message"])
    }

    if (data["Note"]) {
      throw new Error(data["Note"]) // This catches rate limit errors
    }

    const timeSeries = data["Time Series (Daily)"]
    if (!timeSeries || Object.keys(timeSeries).length === 0) {
      throw new Error("No data available for this symbol. The stock symbol may be invalid or not supported.")
    }

    const dates = Object.keys(timeSeries).slice(0, 30).reverse() // Get last 30 days of data
    const historicalData = dates.map((date) => ({
      date,
      price: Number.parseFloat(timeSeries[date]["4. close"]),
    }))

    return NextResponse.json({
      symbol,
      currentPrice: historicalData[historicalData.length - 1].price,
      historicalData,
    })
  } catch (error) {
    console.error("Error fetching stock data:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch stock data",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

