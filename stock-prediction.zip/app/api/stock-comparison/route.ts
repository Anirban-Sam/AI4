import { NextResponse } from "next/server"

const API_KEY = process.env.ALPHA_VANTAGE_API_KEY

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const symbol1 = searchParams.get("symbol1")
  const symbol2 = searchParams.get("symbol2")

  if (!symbol1 || !symbol2) {
    return NextResponse.json({ error: "Both symbols are required" }, { status: 400 })
  }

  if (!API_KEY) {
    return NextResponse.json({ error: "API key is not configured" }, { status: 500 })
  }

  try {
    const [data1, data2] = await Promise.all([fetchStockData(symbol1), fetchStockData(symbol2)])

    const comparisonData = combineStockData(data1, data2)
    const comparisonResult = compareStocks(comparisonData, symbol1, symbol2)

    return NextResponse.json({ data: comparisonData, comparisonResult })
  } catch (error) {
    console.error("Error fetching comparison data:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch comparison data" },
      { status: 500 },
    )
  }
}

async function fetchStockData(symbol: string) {
  const response = await fetch(
    `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&apikey=${API_KEY}`,
  )
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`)
  }
  const data = await response.json()

  if (data["Error Message"]) {
    throw new Error(data["Error Message"])
  }

  if (data["Note"]) {
    throw new Error(data["Note"]) // This catches rate limit errors
  }

  if (!data["Time Series (Daily)"]) {
    throw new Error(`No data available for symbol: ${symbol}`)
  }

  return data
}

function combineStockData(data1: any, data2: any) {
  const timeSeries1 = data1["Time Series (Daily)"]
  const timeSeries2 = data2["Time Series (Daily)"]

  const combinedData = Object.keys(timeSeries1).map((date) => ({
    date,
    [data1["Meta Data"]["2. Symbol"]]: Number.parseFloat(timeSeries1[date]["4. close"]),
    [data2["Meta Data"]["2. Symbol"]]: Number.parseFloat(timeSeries2[date]["4. close"]),
  }))

  return combinedData.slice(0, 30).reverse() // Return last 30 days of data
}

function compareStocks(data: any[], symbol1: string, symbol2: string) {
  if (data.length === 0) {
    return "Insufficient data for comparison"
  }

  const firstDay = data[0]
  const lastDay = data[data.length - 1]

  const change1 = ((lastDay[symbol1] - firstDay[symbol1]) / firstDay[symbol1]) * 100
  const change2 = ((lastDay[symbol2] - firstDay[symbol2]) / firstDay[symbol2]) * 100

  if (change1 > 0 && change2 > 0) {
    return `Both ${symbol1} and ${symbol2} are profitable. ${symbol1} increased by ${change1.toFixed(2)}% and ${symbol2} increased by ${change2.toFixed(2)}%. ${change1 > change2 ? symbol1 : symbol2} performed better.`
  } else if (change1 < 0 && change2 < 0) {
    return `Both ${symbol1} and ${symbol2} are at a loss. ${symbol1} decreased by ${Math.abs(change1).toFixed(2)}% and ${symbol2} decreased by ${Math.abs(change2).toFixed(2)}%. ${change1 > change2 ? symbol1 : symbol2} had less loss.`
  } else {
    const profitSymbol = change1 > 0 ? symbol1 : symbol2
    const lossSymbol = change1 > 0 ? symbol2 : symbol1
    const profitChange = change1 > 0 ? change1 : change2
    const lossChange = change1 > 0 ? Math.abs(change2) : Math.abs(change1)
    return `${profitSymbol} is profitable with a ${profitChange.toFixed(2)}% increase, while ${lossSymbol} is at a loss with a ${lossChange.toFixed(2)}% decrease. The price difference is ${Math.abs(profitChange + lossChange).toFixed(2)}%.`
  }
}

