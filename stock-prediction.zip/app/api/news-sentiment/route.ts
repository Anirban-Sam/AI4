import { NextResponse } from "next/server"

const API_KEY = process.env.ALPHA_VANTAGE_API_KEY

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const symbol = searchParams.get("symbol")

  if (!symbol) {
    return NextResponse.json({ error: "Symbol is required" }, { status: 400 })
  }

  if (!API_KEY) {
    return NextResponse.json({ error: "API key is not configured" }, { status: 500 })
  }

  try {
    const response = await fetch(
      `https://www.alphavantage.co/query?function=NEWS_SENTIMENT&tickers=${symbol}&apikey=${API_KEY}`,
    )
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }
    const data = await response.json()

    if (data["Error Message"]) {
      throw new Error(data["Error Message"])
    }

    if (data["Note"]) {
      throw new Error(data["Note"]) // This catches rate limit errors
    }

    if (!data.feed || !Array.isArray(data.feed) || data.feed.length === 0) {
      throw new Error("No news data available for this symbol")
    }

    const news = data.feed.map((item: any) => ({
      title: item.title,
      summary: item.summary,
      sentiment: item.overall_sentiment_label,
      source: item.source,
      publishedAt: item.time_published,
    }))

    return NextResponse.json(news)
  } catch (error) {
    console.error("Error fetching news:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch news data" },
      { status: 500 },
    )
  }
}

