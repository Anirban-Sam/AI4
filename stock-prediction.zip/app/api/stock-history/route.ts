import { NextResponse } from "next/server"

const API_KEY = process.env.ALPHA_VANTAGE_API_KEY

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const symbol = searchParams.get("symbol")

  if (!symbol) {
    return NextResponse.json({ error: "Symbol is required" }, { status: 400 })
  }

  if (!API_KEY) {
    return NextResponse.json({ error: "API key is not configured" }, { status: 500 })
  }

  try {
    const response = await fetch(
      `https://www.alphavantage.co/query?function=TIME_SERIES_MONTHLY&symbol=${symbol}&apikey=${API_KEY}`,
    )

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()

    if (data["Error Message"]) {
      throw new Error(data["Error Message"])
    }

    if (data["Note"]) {
      throw new Error(data["Note"]) // This catches rate limit errors
    }

    const monthlyData = data["Monthly Time Series"]

    if (!monthlyData) {
      throw new Error("No monthly data available for this symbol")
    }

    const historicalData = Object.entries(monthlyData).map(([date, values]: [string, any]) => ({
      date,
      price: Number.parseFloat(values["4. close"]),
    }))

    return NextResponse.json(historicalData.reverse().slice(0, 540)) // 45 years of monthly data
  } catch (error) {
    console.error("Error fetching historical data:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch historical data" },
      { status: 500 },
    )
  }
}

