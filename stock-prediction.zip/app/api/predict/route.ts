import { NextResponse } from "next/server"

const API_KEY = process.env.ALPHA_VANTAGE_API_KEY

async function fetchData(symbol: string) {
  const response = await fetch(
    `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&apikey=${API_KEY}`,
  )
  if (!response.ok) {
    throw new Error(`API responded with status ${response.status}`)
  }
  const data = await response.json()
  if (data["Error Message"]) {
    throw new Error(data["Error Message"])
  }
  if (data["Note"]) {
    throw new Error(data["Note"])
  }
  return data
}

export async function POST(req: Request) {
  try {
    const { symbol } = await req.json()

    if (!symbol) {
      return NextResponse.json({ error: "Symbol is required" }, { status: 400 })
    }

    if (!API_KEY) {
      return NextResponse.json({ error: "API key is not configured" }, { status: 500 })
    }

    const data = await fetchData(symbol)
    const timeSeries = data["Time Series (Daily)"]

    if (!timeSeries || Object.keys(timeSeries).length === 0) {
      return NextResponse.json(
        { error: "No time series data available for this symbol. The stock symbol may be invalid or not supported." },
        { status: 404 },
      )
    }

    const dates = Object.keys(timeSeries).slice(0, 30).reverse() // Get last 30 data points
    const historicalData = dates.map((date) => ({
      date,
      price: Number.parseFloat(timeSeries[date]["4. close"]),
      open: Number.parseFloat(timeSeries[date]["1. open"]),
      high: Number.parseFloat(timeSeries[date]["2. high"]),
      low: Number.parseFloat(timeSeries[date]["3. low"]),
      volume: Number.parseInt(timeSeries[date]["5. volume"]),
    }))

    const currentPrice = historicalData[historicalData.length - 1].price

    return NextResponse.json({
      historicalData,
      currentPrice,
      dataType: "Daily",
    })
  } catch (error) {
    console.error("Error fetching stock data:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch stock data" },
      { status: 500 },
    )
  }
}

