"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"

interface Question {
  id: number
  text: string
  options: string[]
}

const questions: Question[] = [
  {
    id: 1,
    text: "How did you hear about us?",
    options: ["Social Media", "Friend/Colleague", "Search Engine", "Advertisement", "Other"],
  },
  {
    id: 2,
    text: "What is your primary investment goal?",
    options: ["Long-term Growth", "Day Trading", "Passive Income", "Learning/Research", "Portfolio Diversification"],
  },
  {
    id: 3,
    text: "What is your trading experience level?",
    options: ["Beginner", "Intermediate", "Advanced", "Professional", "Expert"],
  },
  {
    id: 4,
    text: "Which features are most important to you?",
    options: ["Real-time Data", "Technical Analysis", "AI Predictions", "News Integration", "Portfolio Management"],
  },
  {
    id: 5,
    text: "How often do you plan to use our platform?",
    options: ["Daily", "Weekly", "Monthly", "Occasionally", "Not Sure"],
  },
]

export default function SurveyPage() {
  const router = useRouter()
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const progress = ((currentQuestion + 1) / questions.length) * 100

  const handleAnswer = (answer: string) => {
    setAnswers((prev) => ({ ...prev, [questions[currentQuestion].id]: answer }))
  }

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
    } else {
      // Submit survey and proceed to guided tour
      router.push("/tour")
    }
  }

  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion((prev) => prev - 1)
    }
  }

  const currentQuestionData = questions[currentQuestion]

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Help us personalize your experience</CardTitle>
          <CardDescription>
            Question {currentQuestion + 1} of {questions.length}
          </CardDescription>
          <Progress value={progress} className="mt-2" />
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="text-xl font-medium">{currentQuestionData.text}</div>
            <RadioGroup onValueChange={handleAnswer} value={answers[currentQuestionData.id]} className="space-y-3">
              {currentQuestionData.options.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <RadioGroupItem value={option} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`}>{option}</Label>
                </div>
              ))}
            </RadioGroup>

            <div className="flex justify-between mt-8">
              <Button variant="outline" onClick={handleBack} disabled={currentQuestion === 0}>
                Back
              </Button>
              <Button onClick={handleNext} disabled={!answers[currentQuestionData.id]}>
                {currentQuestion === questions.length - 1 ? "Finish" : "Next"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

