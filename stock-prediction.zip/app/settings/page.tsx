"use client"

import { useState } from "react"
import { Layout } from "@/components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { auth } from "@/lib/firebase"
import { signOut, updateProfile, updateEmail, updatePassword } from "firebase/auth"
import { useRouter } from "next/navigation"

export default function SettingsPage() {
  const [displayName, setDisplayName] = useState(auth.currentUser?.displayName || "")
  const [email, setEmail] = useState(auth.currentUser?.email || "")
  const [password, setPassword] = useState("")
  const router = useRouter()

  const handleUpdateProfile = async () => {
    if (auth.currentUser) {
      try {
        await updateProfile(auth.currentUser, { displayName })
        if (email !== auth.currentUser.email) {
          await updateEmail(auth.currentUser, email)
        }
        if (password) {
          await updatePassword(auth.currentUser, password)
        }
        // Show success message
      } catch (error) {
        console.error("Error updating profile:", error)
        // Show error message
      }
    }
  }

  const handleLogout = async () => {
    try {
      await signOut(auth)
      router.push("/landing")
    } catch (error) {
      console.error("Error signing out:", error)
      // Show error message
    }
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Settings</CardTitle>
            <CardDescription>Manage your account settings and preferences.</CardDescription>
          </CardHeader>
          <CardContent>
            <form>
              <div className="grid w-full items-center gap-4">
                <div className="flex flex-col space-y-1.5">
                  <Label htmlFor="name">Name</Label>
                  <Input id="name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
                </div>
                <div className="flex flex-col space-y-1.5">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="flex flex-col space-y-1.5">
                  <Label htmlFor="password">New Password</Label>
                  <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
              </div>
            </form>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={handleLogout}>
              Logout
            </Button>
            <Button onClick={handleUpdateProfile}>Save Changes</Button>
          </CardFooter>
        </Card>
      </div>
    </Layout>
  )
}

