import Link from 'next/link'
import { Layout } from '@/components/layout'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function NotFound() {
  return (
    <Layout>
      <Card className="bg-white/10 backdrop-blur-md border-gray-500/50 max-w-lg mx-auto mt-20">
        <CardHeader>
          <CardTitle className="text-3xl text-gray-300 text-center">404 - Page Not Found</CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-gray-200 mb-6">
            Oops! The page you're looking for doesn't exist or has been moved.
          </p>
          <Link href="/" passHref>
            <Button className="bg-gray-600 hover:bg-gray-700">
              Return to Home
            </Button>
          </Link>
        </CardContent>
      </Card>
    </Layout>
  )
}

