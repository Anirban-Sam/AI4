"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Layout } from "@/components/layout"
import { MarketData } from "@/components/MarketData"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog"
import { Settings, LogOut } from "lucide-react"
import { auth } from "@/lib/firebase"
import { motion } from "framer-motion"

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        setUser(user)
      } else {
        router.push("/signup")
      }
    })

    return () => unsubscribe()
  }, [router])

  const handleLogout = async () => {
    try {
      await auth.signOut()
      router.push("/landing")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  if (!user) {
    return <div>Loading...</div>
  }

  const gradients = [
    "bg-gradient-to-r from-purple-400 to-pink-600",
    "bg-gradient-to-r from-blue-400 to-green-500",
    "bg-gradient-to-r from-yellow-400 to-red-500",
    "bg-gradient-to-r from-indigo-400 to-cyan-400",
  ]

  const randomGradient = gradients[Math.floor(Math.random() * gradients.length)]

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold">Welcome, {user.displayName || user.email}</h1>
            <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className={`rounded-full w-12 h-12 ${randomGradient}`}>
                  {user.displayName ? user.displayName[0].toUpperCase() : user.email[0].toUpperCase()}
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Account Settings</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="flex items-center gap-4">
                    <div
                      className={`w-12 h-12 rounded-full ${randomGradient} flex items-center justify-center text-white text-xl font-bold`}
                    >
                      {user.displayName ? user.displayName[0].toUpperCase() : user.email[0].toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium">{user.displayName || "No display name"}</p>
                      <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                  </div>
                  <div>
                    <p className="font-medium">Subscription: Free</p>
                    <Button className="mt-2" variant="outline">
                      Upgrade to Premium
                    </Button>
                  </div>
                  <div>
                    <p className="font-medium mb-2">Linked Accounts (Max 2)</p>
                    <Button variant="outline" className="w-full mb-2">
                      Add Account
                    </Button>
                    <Button variant="outline" className="w-full">
                      Switch Account
                    </Button>
                  </div>
                  <Button variant="destructive" onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Log Out
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          <MarketData />
        </motion.div>
      </div>
    </Layout>
  )
}

