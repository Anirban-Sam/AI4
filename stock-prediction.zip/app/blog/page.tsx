import { Layout } from '@/components/layout'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const blogPosts = [
  {
    title: "Introduction to Stock Trading",
    description: "Learn the basics of stock trading in this comprehensive guide for beginners.",
    videoId: "Xn7KWR9EOGM"
  },
  {
    title: "Technical Analysis Fundamentals",
    description: "Discover how to read and interpret stock charts using technical analysis.",
    videoId: "eynxyoKgpng"
  },
  {
    title: "Fundamental Analysis Explained",
    description: "Understand how to evaluate a company's financial health and potential for growth.",
    videoId: "7r8SNnDODFc"
  }
]

export default function Blog() {
  return (
    <Layout>
      <div className="space-y-8">
        <Card className="bg-white/10 backdrop-blur-md border-purple-500/50">
          <CardHeader>
            <CardTitle className="text-2xl text-purple-300">StockPredict Blog</CardTitle>
            <CardDescription className="text-purple-200">Educational resources and expert insights</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              {blogPosts.map((post, index) => (
                <Card key={index} className="bg-purple-900/30 border-purple-500/50">
                  <CardHeader>
                    <CardTitle className="text-lg text-purple-300">{post.title}</CardTitle>
                    <CardDescription className="text-purple-200">{post.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="aspect-w-16 aspect-h-9">
                      <iframe
                        src={`https://www.youtube.com/embed/${post.videoId}`}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        className="w-full h-full rounded-md"
                      ></iframe>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}

