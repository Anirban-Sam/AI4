"use client"

import { useRef, useEffect } from "react"
import { Layout } from "@/components/layout"
import { Hero } from "@/components/landing/Hero"
import { Features } from "@/components/landing/Features"
import { Testimonials } from "@/components/landing/Testimonials"
import { Pricing } from "@/components/landing/Pricing"
import { CallToAction } from "@/components/landing/CallToAction"
import { Footer } from "@/components/landing/Footer"
import { Button } from "@/components/ui/button"
import { Star, DollarSign, Zap, Users } from "lucide-react"
import { motion } from "framer-motion"

const stockSymbols = ["AAPL", "GOOGL", "MSFT", "AMZN", "FB", "TSLA", "NVDA", "JPM", "V", "JNJ"]

export default function LandingPage() {
  const featuresRef = useRef<HTMLDivElement>(null)
  const testimonialsRef = useRef<HTMLDivElement>(null)
  const pricingRef = useRef<HTMLDivElement>(null)
  const aboutRef = useRef<HTMLDivElement>(null)

  const scrollToSection = (ref: React.RefObject<HTMLDivElement>) => {
    ref.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    const symbols = document.getElementById("stock-symbols")
    if (symbols) {
      const createSymbol = () => {
        const symbol = document.createElement("div")
        symbol.innerText = stockSymbols[Math.floor(Math.random() * stockSymbols.length)]
        symbol.style.position = "absolute"
        symbol.style.left = `${Math.random() * 100}%`
        symbol.style.top = `${Math.random() * 100}%`
        symbol.style.opacity = "0.1"
        symbol.style.fontSize = `${Math.random() * 20 + 10}px`
        symbol.style.transform = `rotate(${Math.random() * 360}deg)`
        symbols.appendChild(symbol)

        setTimeout(() => {
          symbol.remove()
        }, 10000)
      }

      setInterval(createSymbol, 1000)
    }
  }, [])

  return (
    <Layout>
      <div className="relative overflow-hidden">
        <div id="stock-symbols" className="absolute inset-0 pointer-events-none" />

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Hero />
        </motion.div>

        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-center space-x-4 mb-12">
            <Button onClick={() => scrollToSection(featuresRef)}>
              <Zap className="w-4 h-4 mr-2" />
              Features
            </Button>
            <Button onClick={() => scrollToSection(testimonialsRef)}>
              <Star className="w-4 h-4 mr-2" />
              Reviews
            </Button>
            <Button onClick={() => scrollToSection(pricingRef)}>
              <DollarSign className="w-4 h-4 mr-2" />
              Pricing
            </Button>
            <Button onClick={() => scrollToSection(aboutRef)}>
              <Users className="w-4 h-4 mr-2" />
              About Us
            </Button>
          </div>

          <motion.div
            ref={featuresRef}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Features />
          </motion.div>

          <motion.div
            ref={testimonialsRef}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Testimonials />
          </motion.div>

          <motion.div
            ref={pricingRef}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Pricing />
          </motion.div>

          <motion.div
            ref={aboutRef}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="py-12 text-center">
              <h2 className="text-3xl font-bold mb-4">About StockPredictor</h2>
              <p className="max-w-2xl mx-auto">
                StockPredictor is a cutting-edge platform that leverages AI and machine learning to provide accurate
                stock market predictions and insights. Our team of experts is dedicated to helping investors make
                informed decisions.
              </p>
            </div>
          </motion.div>
        </div>

        <CallToAction />
        <Footer />
      </div>
    </Layout>
  )
}

