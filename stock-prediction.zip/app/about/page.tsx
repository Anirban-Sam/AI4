import { Layout } from '@/components/layout'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function About() {
  return (
    <Layout>
      <Card className="bg-white/10 backdrop-blur-md">
        <CardHeader>
          <CardTitle className="text-2xl text-gray-300">About Stock App</CardTitle>
          <CardDescription className="text-gray-200">Learn more about our stock prediction platform</CardDescription>
        </CardHeader>
        <CardContent className="text-white">
          <p className="mb-4">
            Stock App is a platform that provides stock price predictions. Our goal is to empower investors with the insights they need to make informed decisions in the stock market.
          </p>
          <p className="mb-4">
            With Stock App, you can:
          </p>
          <ul className="list-disc list-inside mb-4">
            <li>Get instant price predictions for any stock</li>
            <li>Access comprehensive market data and analysis</li>
            <li>Stay updated with the latest financial news</li>
            <li>Learn from our educational resources and expert insights</li>
          </ul>
          <p>
            Whether you're a seasoned trader or just starting out, Stock App provides the tools and information you need to navigate the stock market with confidence.
          </p>
        </CardContent>
      </Card>
    </Layout>
  )
}

