import { SignUp } from "@/components/auth/SignUp"
import { Layout } from "@/components/layout"

export default function SignUpPage() {
  return (
    <Layout>
      <div className="flex justify-center items-center min-h-screen bg-gray-100">
        <SignUp />
      </div>
    </Layout>
  )
}

